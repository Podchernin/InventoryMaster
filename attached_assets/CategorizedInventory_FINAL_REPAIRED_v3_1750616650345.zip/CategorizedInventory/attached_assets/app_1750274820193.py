from flask import Flask, render_template, request, redirect, url_for, flash
import os
import shutil
from werkzeug.utils import secure_filename
from datetime import datetime
import logging

# Set up logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fallback_secret_key_for_development")

# Configuration
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif','xlsx', 'docx', 'doc', 'pdf', 'odt'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size


def allowed_file(filename):
    """Check if the file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def create_category_folder(category):
    """Create a folder for a category if it doesn't exist"""
    path = os.path.join(app.config['UPLOAD_FOLDER'], category)
    os.makedirs(path, exist_ok=True)
    return path


@app.route('/')
def index():
    """Home page showing categories and recent uploads"""
    categories = []
    if os.path.exists(UPLOAD_FOLDER):
        categories = [d for d in os.listdir(UPLOAD_FOLDER)
                      if os.path.isdir(os.path.join(UPLOAD_FOLDER, d))]

    # Get the 12 most recent photos from all categories
    recent_photos = []
    for category in categories:
        category_path = os.path.join(UPLOAD_FOLDER, category)
        try:
            # Get all photos and sort them by name (which includes timestamp)
            photos = sorted(os.listdir(category_path), reverse=True)[:6]
        except (FileNotFoundError, IndexError):
            photos = []
        
        for photo in photos:
            recent_photos.append({
                'path': f"{category}/{photo}",
                'category': category,
                'filename': photo
            })
    
    # Sort by filename to get most recent first (since we include timestamp in filename)
    recent_photos.sort(key=lambda x: x['filename'], reverse=True)
    
    return render_template('index.html',
                           categories=categories,
                           recent_photos=recent_photos[:12])  # Show 12 most recent


@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle multiple file uploads with category assignment"""
    if 'photos' not in request.files:
        flash('Файлы не выбраны')
        return redirect(url_for('index'))

    files = request.files.getlist('photos')
    category = request.form.get('category', 'general').strip()
    
    # Validate category name
    if not category:
        category = 'general'
    
    # Sanitize category name
    category = secure_filename(category)

    if not files or all(file.filename == '' for file in files):
        flash('Файлы не выбраны')
        return redirect(url_for('index'))

    # Create category folder if it doesn't exist
    category_path = create_category_folder(category)
    
    # Count successful uploads
    successful_uploads = 0
    failed_uploads = 0

    for file in files:
        if not file or not file.filename or file.filename == '':
            continue
            
        if allowed_file(file.filename):
            # Generate a unique filename using timestamp with milliseconds
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]  # Include milliseconds for uniqueness
            filename = f"{timestamp}_{secure_filename(file.filename)}"

            file_path = os.path.join(category_path, filename)
            file.save(file_path)
            
            logging.debug(f"File saved to: {file_path}")
            successful_uploads += 1
        else:
            failed_uploads += 1
    
    # Provide appropriate feedback
    if successful_uploads > 0:
        if failed_uploads > 0:
            flash(f'Загружено {successful_uploads} фото. {failed_uploads} файлов не загружены (неверный формат).')
        else:
            flash(f'Успешно загружено {successful_uploads} фото.')
    else:
        flash('Не удалось загрузить фотографии. Разрешены только форматы: png, jpg, jpeg, gif, docx, doc, pdf, odt, xlsx')

    return redirect(url_for('index'))


@app.route('/category/<category_name>')
def show_category(category_name):
    """Display all photos in a specific category"""
    category_path = os.path.join(app.config['UPLOAD_FOLDER'], category_name)
    if not os.path.exists(category_path):
        flash('Категория не найдена')
        return redirect(url_for('index'))

    try:
        # Sort photos by filename (newest first)
        photos = sorted(os.listdir(category_path), reverse=True)
    except FileNotFoundError:
        photos = []
        flash('В данной категории пока нет фотографий.')

    return render_template('category.html',
                           category=category_name,
                           photos=photos)


@app.route('/delete/<category_name>/<filename>', methods=['POST'])
def delete_photo(category_name, filename):
    """Delete a photo from a category"""
    # Create the full path to the photo
    photo_path = os.path.join(app.config['UPLOAD_FOLDER'], category_name, filename)
    
    # Check if the file exists
    if not os.path.exists(photo_path):
        flash('Фото не найдено')
        return redirect(url_for('show_category', category_name=category_name))
    
    try:
        # Delete the file
        os.remove(photo_path)
        logging.debug(f"Deleted photo: {photo_path}")
        flash('Фото успешно удалено')
        
        # Check if the category is now empty
        category_path = os.path.join(app.config['UPLOAD_FOLDER'], category_name)
        if not os.listdir(category_path):
            # If empty, ask user if they want to delete the category as well
            return redirect(url_for('show_category', category_name=category_name, empty=True))
        
    except Exception as e:
        logging.error(f"Error deleting photo: {e}")
        flash('Ошибка при удалении фото')
    
    return redirect(url_for('show_category', category_name=category_name))


@app.route('/delete-category/<category_name>', methods=['POST'])
def delete_category(category_name):
    """Delete an entire category folder"""
    category_path = os.path.join(app.config['UPLOAD_FOLDER'], category_name)
    
    # Check if directory exists
    if not os.path.exists(category_path):
        flash('Категория не найдена')
        return redirect(url_for('index'))
    
    try:
        # Delete the entire directory
        shutil.rmtree(category_path)
        logging.debug(f"Deleted category: {category_path}")
        flash(f'Категория "{category_name}" успешно удалена')
    except Exception as e:
        logging.error(f"Error deleting category: {e}")
        flash('Ошибка при удалении категории')
    
    return redirect(url_for('index'))


# Create upload folder on startup
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
