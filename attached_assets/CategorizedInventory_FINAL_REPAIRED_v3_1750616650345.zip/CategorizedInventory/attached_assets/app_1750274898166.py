from flask import Flask, render_template, request, redirect, url_for, flash
import os
from werkzeug.utils import secure_filename
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# Конфигурация
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def create_category_folder(category):
    path = os.path.join(app.config['UPLOAD_FOLDER'], category)
    os.makedirs(path, exist_ok=True)
    return path


@app.route('/')
def index():
    categories = []
    if os.path.exists(UPLOAD_FOLDER):
        categories = [d for d in os.listdir(UPLOAD_FOLDER)
                      if os.path.isdir(os.path.join(UPLOAD_FOLDER, d))]

    # Получаем последние 6 фото из всех категорий
    recent_photos = []
    for category in categories:
        category_path = os.path.join(UPLOAD_FOLDER, category)
        try:  # добавил try-except для обработки ошибки, если категория пуста
            photos = os.listdir(category_path)[-6:]  # Последние 6 фото
        except (FileNotFoundError, IndexError):  # Объединил обработку исключений
            photos = []
        for photo in photos:
            recent_photos.append({
                'path': f"{category}/{photo}",
                'category': category
            })

    return render_template('index.html',
                           categories=categories,
                           recent_photos=recent_photos[-12:])  # Показываем 12 последних


@app.route('/upload', methods=['POST'])
def upload_file():
    if 'photo' not in request.files:
        flash('Файл не выбран')
        return redirect(url_for('index'))

    file = request.files['photo']
    category = request.form.get('category', 'general')

    if file.filename == '':
        flash('Файл не выбран')
        return redirect(url_for('index'))

    if file and allowed_file(file.filename):
        # Создаем папку категории, если ее нет
        category_path = create_category_folder(category)

        # Генерируем уникальное имя файла
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{timestamp}_{secure_filename(file.filename)}"

        file.save(os.path.join(category_path, filename))
        flash('Фото успешно загружено')
    else:
        flash('Недопустимый формат файла')

    return redirect(url_for('index'))


@app.route('/category/<category_name>')
def show_category(category_name):
    category_path = os.path.join(app.config['UPLOAD_FOLDER'], category_name)
    if not os.path.exists(category_path):
        flash('Категория не найдена')
        return redirect(url_for('index'))

    try:  # Обработка ошибки, если категория пуста
        photos = os.listdir(category_path)
    except FileNotFoundError:
        photos = []
        flash('В данной категории пока нет фотографий.')  # Добавляем сообщение

    return render_template('category.html',
                           category=category_name,
                           photos=photos)


if __name__ == '__main__':
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=True)
